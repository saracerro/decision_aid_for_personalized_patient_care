
clc;
clear;
close all;

% %% === Parametri ===
% filename = 'dataset_weaning_prova.xlsx';
% sheet_normalized = 'DATASET_Step3d';   % Dataset normalizzato
% sheet_original    = 'DATASET_V1';      % Dataset originale
% colsToDenormalize = 4:57;              % Colonne delle feature (modifica se serve)
% 
% %% === Lettura dei dataset ===
% dataset_norm = readtable(filename, 'Sheet', sheet_normalized);
% dataset_orig = readtable(filename, 'Sheet', sheet_original);
% 
% %% === Calcolo min e max dalle colonne originali ===
% min_val = min(dataset_orig{:, colsToDenormalize}, [], 1, 'omitnan');
% max_val = max(dataset_orig{:, colsToDenormalize}, [], 1, 'omitnan');
% 
% %% === Denormalizzazione ===
% dataset_denorm = dataset_norm;  % Copia del dataset normalizzato
% for i = 1:length(colsToDenormalize)
%     col = colsToDenormalize(i);
%     dataset_denorm{:, col} = dataset_norm{:, col} .* (max_val(i) - min_val(i)) + min_val(i);
% end
% 
% %% === Salvataggio ===
% writetable(dataset_denorm, filename, 'Sheet', 'DATASET_Step3d_denorm');
% disp('✅ Dataset denormalizzato salvato nel foglio "DATASET_Step3d_denorm".');
%%
clc
clear
close all

% === Parametri iniziali ===
filename = 'dataset_weaning_D_denorm.xlsx';         % Nome del file Excel
sheetName = 'DATASET_Step3d_denorm'; % Nome del foglio
%CONTROLLA CHE LE VARIABILI SIANO CONTINUE/INTERE
%CLUSTER 14
variabili = {'MRH','NP','chloride_min_value','hemoglobin_min_value','CPC','PT_min_value', 'heart_rate_min_value'};               % <--- Inserisci qui i nomi delle variabili che vuoi plottare
%CLUSTER 6
%variabili = {'CPC','sedation_days','PT_min_value','heart_rate_min_value','heart_rate_trend','respiratory_rate_trend','tidal_volume_trend','mean_airway_pressure_max_value'};               % <--- Inserisci qui i nomi delle variabili che vuoi plottare
%CLUSTER 4
%variabili = {'age','cpc','curares','sedation_days','heart_rate_max_value','heart_rate_trend','respiratory_rate_trend','mean_airway_pressure_max_value'};               % <--- Inserisci qui i nomi delle variabili che vuoi plottare
%CLUSTER 17
%variabili = {'total_comorbility','gcs','vasopressors','sedation_days','pH_max_value','heart_rate_max_value','heart_rate_trend'};               % <--- Inserisci qui i nomi delle variabili che vuoi plottare

% === Caricamento del dataset ===
dataset = readtable(filename, 'Sheet', sheetName);

% === Creazione boxplot per ogni variabile ===
for i = 1:length(variabili)
    varName = variabili{i};

    % Controlla che la variabile esista nel dataset
    if ismember(varName, dataset.Properties.VariableNames)
        valore = dataset.(varName);
        valore = valore(~ismissing(valore));  % Rimuove NaN

        % Crea il boxplot
        figure;
        boxplot(valore);
        title(['Boxplot for variable: ', varName], 'Interpreter', 'none');
        ylabel(varName, 'Interpreter', 'none');

        % Salvataggio opzionale
        %saveas(gcf, ['Boxplot_' varName '.png']);
        figure;
        histogram(valore, 'BinMethod', 'fd', 'FaceColor', [0.2 0.4 0.6]);  % 'fd' usa la regola di Freedman-Diaconis per i bin
        title(['Value Distribution - ', varName], 'Interpreter', 'none');
        xlabel(varName, 'Interpreter', 'none');
        ylabel('Frequency');

         % === Calcolo dei percentili ===
        P = prctile(valore, [10 20 25 30 50 60 70 75 80 90 95]);

        % === Visualizza in console ===
        fprintf('\n=== %s ===\n', varName);
        fprintf('10° percentile: %.2f\n', P(1));
        fprintf('20° percentile: %.2f\n', P(2));
        fprintf('25° percentile: %.2f\n', P(3));        
        fprintf('30° percentile: %.2f\n', P(4));
        fprintf('50° percentile: %.2f\n', P(5));
                 fprintf('60° percentile: %.2f\n', P(6));

        fprintf('70° percentile: %.2f\n', P(7));
                fprintf('75° percentile: %.2f\n', P(8));

        fprintf('80° percentile: %.2f\n', P(9));
        fprintf('90° percentile: %.2f\n', P(10));
                fprintf('95° percentile: %.2f\n', P(11));


    else
        warning(['Variabile non trovata nel dataset: ', varName]);
    end
end