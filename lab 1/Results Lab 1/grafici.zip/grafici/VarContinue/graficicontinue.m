clc
close all
clear

filename = 'dataset_weaning_prova.xlsx';
sheetNames = {'DATASET_Step3a', 'DATASET_Step3b', 'DATASET_Step3c', 'DATASET_Step3d'};
numDatasets = numel(sheetNames);
datasets = cell(1, numDatasets);

% Carica tutti i dataset
for i = 1:numDatasets
    datasets{i} = readtable(filename, 'Sheet', sheetNames{i});
end

% Normalizza solo Step3a e Step3b
colsToNormalize = 4:56;
for i = 1:2
    data = datasets{i};
    for j = colsToNormalize
        colData = data{:, j};
        min_val = min(colData);
        max_val = max(colData);
        if max_val ~= min_val
            data{:, j} = (colData - min_val) / (max_val - min_val);
        else
            data{:, j} = 0;
        end
    end
    datasets{i} = data;
end

% Variabili continue
ContinuousVariables = {'age','total_comorbidity','CPC','MRH','NP','sedation_days','PCO2_min_value','PCO2_max_value','pH_min_value','pH_max_value','chloride_min_value','chloride_max_value','hemoglobin_min_value','hemoglobin_max_value','PTT_min_value','PTT_max_value','platelet_count_min_value','platelet_count_max_value','WBC_min_value','WBC_max_value','PT_min_value','PT_max_value','heart_rate_min_value','heart_rate_max_value','respiratory_rate_min_value','respiratory_rate_max_value','PIP_min_value','PIP_max_value','tidal_volume_min_value','tidal_volume_max_value','mean_airway_pressure_min_value','mean_airway_pressure_max_value','PEEP_min_value','PEEP_max_value'};

% Genera boxplot divisi per classe
for i = 1:length(ContinuousVariables)
    varName = ContinuousVariables{i};

    if ~ismember(varName, datasets{1}.Properties.VariableNames)
        warning(['Variabile non trovata: ', varName]);
        continue;
    end

    dati_box = [];
    gruppi = {};
    
    for j = 1:numDatasets
        data = datasets{j};
        if ~ismember('class', data.Properties.VariableNames)
            warning(['Colonna "class" mancante nel dataset: ', sheetNames{j}]);
            continue;
        end

        for classVal = 0:1
            subset = data(data.class == classVal, :);
            valori = subset.(varName);
            valori = valori(~ismissing(valori));

            dati_box = [dati_box; valori];
            label = [sheetNames{j}, ' - Class ', num2str(classVal)];
            gruppi = [gruppi; repmat({label}, length(valori), 1)];
        end
    end

    figure;
    boxplot(dati_box, gruppi);
    title(['Boxplot for variable: ', varName], 'Interpreter', 'none');
    ylabel(varName, 'Interpreter', 'none');
    xlabel('Dataset - Class');

    saveas(gcf, ['Boxplot_byClass_' varName '.png']);
end
